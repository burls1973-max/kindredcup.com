Kindred Cup — Coming Soon
Generated: 2025-09-09T16:31:00.768850Z

Upload index.html to GitHub Pages and point www.kindredcup.com CNAME to <your-username>.github.io, root @ 301 to https://www.kindredcup.com/
